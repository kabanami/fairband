# Values and provenance

Fairband's whole claim is that you can ask any number on the screen where it came from and when it stops being true. These are the display rules that keep that claim honest.

## One chip, one question

Two glyphs, two questions, and they never share a chip.

**`◆` sits on a write and answers *who did it*** — the principal: Owner, Agent, or System. A write is an override (a change to one tagged input, with a reason), a proposal, a trade, or a policy edit. Render it with `PrincipalChip`.

**`ƒ` sits on a computed number and answers *which inputs went in*** — the basis: **mechanical** means the system's own inputs only; **reviewed** means one or more overrides are inside. Render it with `BasisChip`.

The reason they cannot be combined is structural. **Nobody but the engine ever writes a value.** An agent changes an input; the engine recomputes. So the author of a reviewed value is the System — exactly the same author as the mechanical value. "System did it" is true of both numbers, so the principal can never tell them apart. The basis label is the only thing that can.

A chip that reads `◆ Agent claude-opus-5 · reviewed` is therefore wrong, however natural it looks: it implies the agent produced the number, which no agent ever does.

## Why "an agent touched it" is not the same as "reviewed"

The two coincide at the moment of an override and come apart immediately afterwards. Three cases the UI has to show:

**Both values exist at once.** The mechanical value stays on screen beside the reviewed one — the screen shows both, `ValueBridge` walks from one to the other, and the accuracy log compares them. Two numbers on one row each need a name.

**A period-tied override expires.** The current value falls back to mechanical, even though an agent once reviewed the company. The label says mechanical *now*; the history keeps the agent's write. The basis follows the inputs inside this number, not the company's past.

**Not every Owner write is a review.** Confirming a proposal, recording a trade or editing policy has a principal and a reason, but changes no valuation input, so no basis label moves.

## The value bridge

`ValueBridge` is the one place the two families meet: the mechanical number, one line per override with its tag, from→to, reason and principal, then the reviewed number. The reviewed row sits under a `border-strong` rule so the value column reads as arithmetic the reader can check — the overrides are the terms, the reviewed value is the sum.

On the screen, where a chip per cell is unaffordable, the two values are named by their **column headers** instead, each carrying the `ƒ`. A company with no overrides shows an em dash under Reviewed rather than a repeat of the mechanical figure: a reviewed value that nobody reviewed would be a lie, and the dash is what the accuracy log compares against.

## Naming the principal

`Owner` is you. `System` is the engine's own write. `Agent` carries its role — the model identifier it connected under, `claude-opus-5` or `gpt-5` — set in `mono`, lower case, exactly as it arrived, demoted to `ink-faint` beside the principal.

Never write "AI", "assistant" or "bot". A reader who finds a bad input wants to know which model produced it, and wants the string to match their own MCP logs.

## The three dates

Every value carries three dates, and they answer three different questions. Never collapse them into one "updated" timestamp.

**As of** — the date the fact itself describes. A fiscal period end, a filing date, a price timestamp.

**Observed** — when the value was read from its source. A wide gap between as-of and observed means a number is old news, not that it is wrong.

**Entered** — when the value was written into Fairband. Audit questions are answered with this date, and for an accepted report it is the moment of acceptance, not of research.

Show all three in `caption` wherever there is vertical room, in that order. In a table cell show the entered date only, with the other two in the row's detail.

**Dates read as `3 Dec 2026`.** The ISO string never leaves the markup — it rides in `datetime` and in the element's title, and the table view and every export emit ISO — so sorting, diffing and grepping are unaffected. Never show a relative date: "3 days ago" is unusable when the question is which quarter a number came from.

Dates stay monospaced and right-align in a column, so the varying day width does not ragged the edge.

## The validity window

Every value also carries `validFrom` and `validUntil` — the engine's own statement about how long it will keep trusting the value.

| State | Condition | Colour | Mark |
| --- | --- | --- | --- |
| Current | today is inside the window, before two thirds of it | none | none |
| Aging | today is inside the window, past two thirds of it | `caution` | `!` |
| Expired | today is past `validUntil` | `critical` | `×` |

A **current** value gets no decoration at all. If every healthy value carried a tick, the screen would be unreadable and the two states worth noticing would disappear. Quiet is the signal that nothing is wrong.

An **expired** value still shows its figure, marked, with the date it lapsed. Fairband never hides a number it has.

Render the window with `ValidityWindow`: a `band-track`-high bar from `validFrom` to `validUntil` with today marked by a `radius-pill` cap — the same shape as the price marker in `BandMeter`, because it means the same thing: a point on a scale.

## Reasons

An input change without a reason does not get saved — not by you, not by an agent. `TaggedInput` shows the missing-reason line in `caution` until a reason exists, and an override submitted without one comes back refused rather than applied. An override also needs **evidence**: a source document, a finding, a base rate, or a URL the server stores as text. A note needs only a reason.

Show the reason in `body`, in full, wherever the change is listed. It is the most valuable text in the application and usually two sentences. Truncate the company name first.

A reason is the author's text. Do not rewrite, sentence-case, summarise it or add a period.

## The three agent records

An agent never writes a value. It writes three kinds of record, and each has its own lifecycle, its own states and its own component. Collapsing them into one card — which an earlier version of this system did — hides the thing that matters most: **only one of the three ever waits for you.**

**An override** is a change to one tagged input, with a reason, evidence and a lifetime. The server applies it at once if the rules allow; the engine recomputes and the bridge gains a line. It can be refused — locked input, needs extra evidence, unit or range invalid, a value rather than an input — or come back as a stale-revision conflict. Rendered by `OverrideRecord`, which has no buttons: by the time a reader sees it, it has already happened.

**A report** is a whole revision of the agents' written work on a company, in one of two modes. The server publishes it only when every number traces to a stored fact or an engine metric; otherwise it rejects it with findings per citation, and the published report is unchanged. It moves no value. Rendered by `ReportReader`.

**A proposal** is a trade, a policy change or a thesis revision. It waits in the Inbox with the exact payload the server will apply, bound to a target revision. You confirm it through `ConfirmDialog` or reject it with a reason; if the target moved, the card is stale and the agent must propose again. Rendered by `ProposalCard` — the only agent record with a confirm, and the only place a person gates an agent's work.

Research submissions — a **finding**, a **judgment**, a **note**, a **news item** — are recorded rather than reviewed, and surface in the judgments panel and the thesis rather than as records here.

The one display rule that follows from all of this: **buttons appear only on a proposal.** If an override or a report grows an accept, something has been modelled wrongly.

Never recompute on hover, and never show a derived value the engine has not computed.
