Return on invested capital against the cost of capital, with the gap between them filled. The chart that says whether growth has been worth anything.

## What the consumer provides

`series`, oldest first, each `{ period, roic, wacc }` in percent. Both are percentages, so both sit on one axis — that is what makes two lines legitimate here. Optionally `title`, `subtitle`, `height` (default 180) and `tableView`.

## Rules

**The gap is the subject, so the gap is what gets filled.** `chart-pos-1` where ROIC clears WACC, `chart-neg-1` where it does not. The fill changes at the crossing itself, interpolated between the two periods — not at the next data point, which would colour part of a period the wrong way and overstate how long a company spent destroying value.

ROIC is the subject and takes `chart-1`; WACC is the hurdle and takes `chart-context`, the de-emphasis grey. That is the emphasis form: a hurdle is a reference, not a peer series, and painting it a second identity hue would make the reader compare two things rather than read one against a line.

Two lines means a legend, always. Both line ends are direct-labelled — ROIC in `ink`, WACC in `ink-faint`.

A phase model turns on this chart. A company whose ROIC has sat below its WACC for five years is not a mature-growth company whatever its revenue does, and this is where that shows.

## Don't

Don't add a third line. Revenue growth, reinvestment and margin all belong in their own `HistoryBars`; a third series here would turn an emphasis chart into a categorical one, and Fairband has no categorical palette by design.

Don't put ROIC and an absolute figure on the same plot. One is a percentage; the other is money. Two axes is the one thing these charts never do.

Don't shade the gap when the two lines are within noise of each other. If the spread is under a point, say so in words; a two-pixel wedge of colour is a claim the data cannot support.
