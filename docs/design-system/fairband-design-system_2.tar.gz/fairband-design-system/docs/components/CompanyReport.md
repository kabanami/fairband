The whole company report, composed from the parts. This is a layout, not a bundle export — there is no `Fairband.CompanyReport`. It documents the order the sections go in and the proportions between them, so a report built later is recognisably the same page.

## The order, and why

1. **Header** — ticker, name, phase badge, and the headline value and price. The one `figure-lg` on the page.
2. **`BandMeter`** — where the price sits today, against the three zones and the stance. A reader who only looks at one thing looks at this.
3. **`ValueBridge`** — how the value was reached: the mechanical number, every override with its reason, the reviewed number. It comes before the charts because a reader who doubts the headline figure doubts it immediately.
4. **`BandHistory`** — where the price has sat. Full width, the tallest chart, the only one that gets more than `chart-height`.
5. **Financial history** — `HistoryBars` as small multiples, two to a row. Revenue and FCFF first, because they drive the band; margin and reinvestment below.
6. **`SpreadChart`** — whether any of that growth was worth having.
7. **`SensitivityGrid`** — how much of the band is assumption.
8. **Inbox** — `ProposalCard` for anything waiting on you. The only records on the page that ask for a decision; everything above is already applied or already published.
9. **Report** — `ReportReader`, the agents' written report on the company.

The overrides themselves do not get a section of their own: they are already in the bridge at step 3, where they belong, because what a reader wants to know about an override is what it did to the value.

The rail carries the inputs: `TaggedInput` for each tagged value, with `ValidityWindow` under the one in focus. It is `detail-rail` wide and it scrolls with the page, not independently — a reader comparing an input to a chart should be able to see both.

The charts come after the band and before the inputs on purpose. A reader arrives asking "is this cheap", not "what is the terminal growth rate"; the inputs are the answer to "why does it say that", which is the second question.

## Rules

**One hero.** The value per share in the header is the only `figure-lg` on the page.

**Only the Inbox has buttons.** An override is applied by the time it is rendered and a report is validated by the server; a proposal is the one record that waits for you. If a section above the Inbox grows a confirm, something has been modelled wrongly.

**Charts sit on `surface-raised`**, in panels separated by `hairline`, with `space-8` between sections. A chart's marker rings are drawn in `surface-raised` for that reason — on a different ground they stop doing their job.

**Filters, if any, sit in one row above everything they scope** — never inside a chart panel, and never one per chart. A period range applies to every chart on the page at once.

**The table toggle is one control for the page**, not one per chart. It flips `tableView` on every chart at once, because a reader who wants numbers wants all of them.

When the engine recomputes, hold the previous render at reduced opacity. No skeletons, no spinners, no chart animating in.

## Don't

Don't put the screen's `ScreenTable` on this page. Navigation back to the screen is a link.

Don't add a section without a question it answers. Every block above corresponds to something the reader actually asked, in the order they ask it; a "news" or "peers" panel answers neither and makes the page a portal.

Don't let the rail outgrow the main column. If there are more inputs than fit, group them under headings and collapse the groups the current phase model does not use — `TaggedInput` has `locked` for exactly that.
