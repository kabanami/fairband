The screen: one row per company, every number already computed, nothing editable. It is the first thing Fairband shows and the place its reader spends most of their time.

## When to use it

For any list of companies — the full universe above the size floor, a saved filter, the rows an agent touched this week. A different list of companies is the same table with different `rows`.

Not for a single company. A detail view composes `BandMeter`, `ValueBridge`, `ValidityWindow` and `TaggedInput` instead.

## What the consumer provides

`rows`, already filtered and sorted — `ScreenTable` does neither, and will not. Each row carries `ticker`, `name`, `phase`, the band (`fairLow`, `fairHigh`), `fairValue`, `buyLevel`, `trimLevel`, `price`, `mechanical`, `reviewed`, `overrides` (a count), and optionally `enteredAt`, `freshness` and `selected`.

`columns`, the visible column keys, with `onColumnsChange` to make the chooser live. Omit both and the default eight render with the chooser inert. `Fairband.DEFAULT_COLUMNS` is that default.

`sort` drives the header indicator only — sorting happens in the engine, the only thing that knows how to order a column of values with different validity states.

`dense` pulls rows to `row-height-dense`. `footnote` takes one `caption` line in the bar, for the row count and the size floor. `chooser: false` hides the bar entirely.

## Rules

**Both values appear, each named by its column.** `ƒ Mechanical` and `ƒ Reviewed` carry the glyph in the header, and the cells stay plain figures — a three-thousand-row table has no room for a chip per cell. Mechanical sits in `ink-muted` as the reference; reviewed sits in `ink`.

**A company with no overrides shows an em dash under Reviewed**, not a repeat of the mechanical figure. A reviewed value that nobody reviewed would be a lie, and the dash is what the accuracy log compares against.

**Stance is derived**, from the price against the buy and trim levels, and always rendered as the word. Never pass a stance in.

**The chooser starts from the default eight and can always return to them.** Ticker and Price cannot be switched off. The default is what makes the screen one instrument rather than a spreadsheet; the reset is what makes departing from it safe.

Nothing in a row is a control. A reader who wants to change an input opens the company. The row's only interactions are hover, selection and opening.

Selection shows `surface-selected` plus the 2px `accent` inset edge, never the tint alone.

Dates render as `3 Dec 2026`, monospaced and right-aligned, with ISO in `datetime`. A `freshness` of `aging` or `expired` marks the date with `!` or `×`; a `current` row is left entirely undecorated.

## Don't

Don't colour whole rows by stance. The stance cell carries the word and its colour; a tinted row would drown the phase ramp and the basis columns both.

Don't add a sparkline, a logo or a change-on-day column **to the screen**. Every pixel one takes is a row the reader cannot see. History belongs on the company report, where `BandHistory` gives it room — see [Charts](../charts.md).

Don't paginate. Virtualise if the universe needs it; the reader scrolls one list.
