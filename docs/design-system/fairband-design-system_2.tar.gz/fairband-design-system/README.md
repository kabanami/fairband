# Fairband design system — repo export

Exported 2026-10-29 from the Fairband design system artifact
(`https://claude.ai/artifact/NNVtN1oQwFQAPgn7hZwWEm`), which stays the source of truth.
Nothing here is hand-maintained: re-export when the system changes, rather than editing
these files and letting the two drift.

Drop this folder anywhere in the repo — `fairband/static/design-system/` if you want the
browser to serve it directly, `design-system/` at the root if you'd rather copy pieces into
your static dir at build time.

## Breaking changes since the 28 Oct export

This export is not a drop-in replacement for the previous one. If anything in the repo
already references the design system, these are the things that will no longer resolve.

**Components removed.** `ReportCard` and `ProvenanceChip` are gone.

- `ProvenanceChip` → `PrincipalChip` (◆, who made a write) and `BasisChip` (ƒ, which inputs
  went into a computed number). They are never combined on one chip.
- `ReportCard` → `OverrideRecord`, `ReportReader` and `ProposalCard`, because an agent writes
  three different kinds of record and only one of them waits for a person. `ConfirmDialog` is
  new alongside them.
- `ValueBridge` is new: the walk from the mechanical value to the reviewed one.

**Tokens renamed or removed.** A find-and-replace covers the renames:

| Was | Now |
| --- | --- |
| `--prov-engine` | `--prov-derived` |
| `--prov-agent` | `--prov-input` |
| `--prov-agent-quiet` | `--prov-input-quiet` |
| `--band-below` | `--stance-buy` |
| `--band-in` | `--stance-hold` |
| `--band-above` | `--stance-trim` |

New: `--zone-buy`, `--zone-hold`, `--zone-fair`, `--zone-trim`, `--record-applied`,
`--record-pending`, `--record-refused`, `--record-stale`, and a `--zone-track` size.

**Token values changed.** `--chart-pos-3` and the whole `--chart-neg-*` arm were re-stepped so
the chart ramps and the band meter's zones share their endpoints — a positive bar and the buy
zone are now the same colour by construction. Charts drawn with the old values will look
different; nothing breaks.

**Props changed.** `ValueCell` takes `basis` instead of `origin`; `TaggedInput` takes
`principal` instead of `origin`; `ScreenTable` rows now carry `mechanical`, `reviewed` and
`overrides`, and the component accepts `columns` / `onColumnsChange`. `BandMeter` takes
`fairValue`, `buyLevel` and `trimLevel`.

**Two display rules changed throughout.** Dates render as `3 Dec 2026` with the ISO string in
`datetime`, and the currency symbol is in the text (`$121.30`) rather than a separate unit
caption. `Fairband.formatDate` and `Fairband.formatMoney` are exported if you need them
outside a component.

## What's here

```
tokens/tokens.json        the tokens, source of truth for every value
tokens/tokens.css         generated — CSS custom properties, both themes
tokens/build_tokens.py    regenerates tokens.css from tokens.json
fonts/                    IBM Plex Sans + Mono woff2, @font-face rules, and the OFL text
components/bundle.css     component styles; reads only the custom properties above
components/bundle.js      the React components, one classic script → window.Fairband
components/index.d.ts     prop documentation for the components
docs/                     the brand book, the charting rules, per-component guidelines
previews/gallery.html     every component, running, offline — open it from disk
```

## Using it

**Start here, whatever the UI turns out to be.** Two stylesheets, in this order:

```html
<link rel="stylesheet" href="/static/design-system/fonts/fonts.css">
<link rel="stylesheet" href="/static/design-system/tokens/tokens.css">
<link rel="stylesheet" href="/static/design-system/components/bundle.css">
```

`tokens.css` defines `:root` and `[data-theme="dark"]` together, so dark is the default,
and `[data-theme="light"]` overrides it. Before anyone picks a theme, the page follows the
operating system. Set `document.documentElement.dataset.theme` to pin one.

Type styles come as classes: `display`, `title`, `heading`, `body`, `control`, `label`,
`caption`, `figure`, `figure-lg`, `figure-sm`, `ticker`. Numbers wear the `figure*` classes,
which are monospaced — that split is the system.

**The components are React.** `bundle.js` is a plain classic script, no bundler and no
build step: it reads `window.React` and `window.ReactDOM` and assigns `window.Fairband`.
If Fairband's UI ends up server-rendered instead, `bundle.js` is reference rather than
dependency — but `bundle.css` and the tokens still apply as they are, and each component's
markup is readable straight out of `bundle.js` to port into a Jinja macro. The class names
are the contract either way, so a ported `ScreenTable` and a mounted one look identical.

`previews/gallery.html` is the fastest way to see what you have. It needs no server and no
network: open the file.

## Regenerating

```bash
python3 tokens/build_tokens.py     # tokens.json → tokens.css
```

Stdlib only, no dependencies. Run it after any change to `tokens.json`; never edit
`tokens.css` by hand, since the next run overwrites it.

The rest of the files are copied from the artifact as they are. To refresh them, re-export
rather than patching: the artifact holds the same paths under `project/`, so
`project/components/bundle.js` here is `components/bundle.js`, `project/README.md` is
`docs/brand-book.md`, and `project/tokens.json` is `tokens/tokens.json`.

## For the agents working in this repo

Point them at `docs/brand-book.md` first — it is written as usage rules that name tokens,
which is what a coding agent needs, and it is short. Then `docs/values-and-provenance.md`
for how a number is allowed to be displayed (the three dates, the validity window, the two
provenance glyphs), and `docs/charts.md` before anything draws a chart. The per-component
files under `docs/components/` each say what the consumer supplies and what not to do.

Worth adding to `CLAUDE.md` or `AGENTS.md`: *"UI work follows
`design-system/docs/brand-book.md`. Use the tokens in `design-system/tokens/tokens.css`;
never hard-code a colour, size or radius."*

## Fonts

IBM Plex Sans and IBM Plex Mono, latin subset, weights 400/500/600, vendored rather than
loaded from Google Fonts: Fairband runs on localhost for one person, so this way it renders
identically with no network and no request leaves the machine on a page load.

They are under the SIL Open Font License 1.1, which is fine for a commercial product and
asks only that the licence travel with the files. The full text is in
[`fonts/LICENSE-IBMPlexSans.txt`](fonts/LICENSE-IBMPlexSans.txt) and
[`fonts/LICENSE-IBMPlexMono.txt`](fonts/LICENSE-IBMPlexMono.txt) — one per family, because
each carries its own copyright line. [`fonts/README.md`](fonts/README.md) has the
provenance and the three conditions worth knowing; the one that bites is that a build step
must not strip the licence files out when it copies the `.woff2`s.
