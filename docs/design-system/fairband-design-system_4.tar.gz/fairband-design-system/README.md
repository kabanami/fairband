# Fairband design system — repo export

Exported 2026-11-01 (second build) from the Fairband design system artifact
(`https://claude.ai/artifact/NNVtN1oQwFQAPgn7hZwWEm`), which stays the source of truth.
Nothing here is hand-maintained: re-export when the system changes, rather than editing
these files and letting the two drift.

Drop this folder anywhere in the repo — `fairband/static/design-system/` if you want the
browser to serve it directly, `design-system/` at the root if you'd rather copy pieces into
your static dir at build time.

## New in this build

**`RunProgress`** — an engine run while it is happening: `total`, `done`, `failed`,
optional `stage` and `onShowFailed`. Pending is derived, never passed in. Determinate
only; no spinner, no percentage, and every zero count is left out. `AppHeader` takes
a `run` prop and shows the compact form **in place of** `engineRanAt`, because the
stamp describes the last *finished* run. The failed count stays on a finished run and
becomes a button wherever the app can show those companies.
`docs/components/RunProgress.md` has the rules, including why the screen keeps the
previous run's values while a new one is in flight.


**The screen can be searched and filtered.** All of it lives in the bar `ScreenTable`
already rendered for the count and `Columns ▾`, so it costs no rows.

- `query` + `onQueryChange` put the `FIND` field in the bar. No magnifying glass —
  Fairband has no icon set, so the control is named by a word.
- `filters` + `onFiltersChange` put `Filters ▾` beside `Columns ▾`: stance, phase,
  **cap size** (`Fairband.CAPS` — mega / large / mid / small, with ranges) and
  **sector** (`Fairband.SECTORS` — the eleven GICS names), plus *Reviewed only* and
  *Hide expired*. `Fairband.EMPTY_FILTERS` is the initial state.
- `total` makes the bar read `41 of 4,112 · Clear`. Every active group shows as a
  chip in the bar; clicking a chip clears that group.
- **The component does not filter.** It reports what the reader asked for and the
  caller narrows `rows`, the same contract `sort` already had.
  `previews/gallery.html` → ScreenTable is live, and
  `components/ScreenTable/preview.html` carries the reference filter function.

**Fixed: a class collision shipped in the 1 Nov build.** `Mark` was using `.fb-mark`,
which is already the freshness glyph on a screen row's Entered cell, so that glyph
rendered as a block. The logo's classes are now `.fb-logo*`. Nothing in the React API
changed; restyle only if you had written CSS against `.fb-mark` meaning the logo.

## New since the 29 Oct export

**Fairband has a mark.** Three unequal bands crossed by a price marker — the cover,
cut to the fewest parts that read at 24px.

- `Fairband.Mark` draws it inline from the tokens, so it follows the theme. `size`
  (default 24), `tone: 'ink'` for a one-ink ground, `label: null` where a wordmark
  beside it already names the app.
- `assets/Logos/` holds the flat files for everywhere outside the running app: the
  mark on each ground, the one-ink fallback, and the cover as a 1920×576 PNG for the
  repository README and the social card. `assets/Logos/README.md` is the usage sheet
  — clear space, the 16px floor, and the ink of the one-ink variant.
- `docs/brand-book.md` replaces its old "there is no logo" rule with the lockup rules.

**`AppHeader` is new**, and it is the app's only chrome: 44px, the lockup, the current
view, and when the engine last ran. `views` / `view` / `onViewChange` / `engineRanAt`.
The cover is not a header — at 288px it costs five rows out of ten in a 520px window
— so it stays on the README and the landing page.

**New token:** `--header-height` (44px).

**`formatDate` now handles a timestamp.** `2026-10-29T03:12` used to render as
`29 Oct 2026 T03:12`; it now renders `29 Oct 2026, 03:12`. Plain dates are unchanged.

## Breaking changes since the 28 Oct export

This export is not a drop-in replacement for the previous one. If anything in the repo
already references the design system, these are the things that will no longer resolve.

**Components removed.** `ReportCard` and `ProvenanceChip` are gone.

- `ProvenanceChip` → `PrincipalChip` (◆, who made a write) and `BasisChip` (ƒ, which inputs
  went into a computed number). They are never combined on one chip.
- `ReportCard` → `OverrideRecord`, `ReportReader` and `ProposalCard`, because an agent writes
  three different kinds of record and only one of them waits for a person. `ConfirmDialog` is
  new alongside them.
- `ValueBridge` is new: the walk from the mechanical value to the reviewed one.

**Tokens renamed or removed.** A find-and-replace covers the renames:

| Was | Now |
| --- | --- |
| `--prov-engine` | `--prov-derived` |
| `--prov-agent` | `--prov-input` |
| `--prov-agent-quiet` | `--prov-input-quiet` |
| `--band-below` | `--stance-buy` |
| `--band-in` | `--stance-hold` |
| `--band-above` | `--stance-trim` |

New: `--zone-buy`, `--zone-hold`, `--zone-fair`, `--zone-trim`, `--record-applied`,
`--record-pending`, `--record-refused`, `--record-stale`, and a `--zone-track` size.

**Token values changed.** `--chart-pos-3` and the whole `--chart-neg-*` arm were re-stepped so
the chart ramps and the band meter's zones share their endpoints — a positive bar and the buy
zone are now the same colour by construction. Charts drawn with the old values will look
different; nothing breaks.

**Props changed.** `ValueCell` takes `basis` instead of `origin`; `TaggedInput` takes
`principal` instead of `origin`; `ScreenTable` rows now carry `mechanical`, `reviewed` and
`overrides`, and the component accepts `columns` / `onColumnsChange`. `BandMeter` takes
`fairValue`, `buyLevel` and `trimLevel`.

**Two display rules changed throughout.** Dates render as `3 Dec 2026` with the ISO string in
`datetime`, and the currency symbol is in the text (`$121.30`) rather than a separate unit
caption. `Fairband.formatDate` and `Fairband.formatMoney` are exported if you need them
outside a component.

## What's here

```
assets/Logos/             the mark on each ground, the one-ink fallback, the cover
tokens/tokens.json        the tokens, source of truth for every value
tokens/tokens.css         generated — CSS custom properties, both themes
tokens/build_tokens.py    regenerates tokens.css from tokens.json
fonts/                    IBM Plex Sans + Mono woff2, @font-face rules, and the OFL text
components/bundle.css     component styles; reads only the custom properties above
components/bundle.js      the React components, one classic script → window.Fairband
components/index.d.ts     prop documentation for the components
docs/                     the brand book, the charting rules, per-component guidelines
previews/gallery.html     every component, running, offline — open it from disk
```

## Using it

**Start here, whatever the UI turns out to be.** Two stylesheets, in this order:

```html
<link rel="stylesheet" href="/static/design-system/fonts/fonts.css">
<link rel="stylesheet" href="/static/design-system/tokens/tokens.css">
<link rel="stylesheet" href="/static/design-system/components/bundle.css">
```

`tokens.css` defines `:root` and `[data-theme="dark"]` together, so dark is the default,
and `[data-theme="light"]` overrides it. Before anyone picks a theme, the page follows the
operating system. Set `document.documentElement.dataset.theme` to pin one.

Type styles come as classes: `display`, `title`, `heading`, `body`, `control`, `label`,
`caption`, `figure`, `figure-lg`, `figure-sm`, `ticker`. Numbers wear the `figure*` classes,
which are monospaced — that split is the system.

**The components are React.** `bundle.js` is a plain classic script, no bundler and no
build step: it reads `window.React` and `window.ReactDOM` and assigns `window.Fairband`.
If Fairband's UI ends up server-rendered instead, `bundle.js` is reference rather than
dependency — but `bundle.css` and the tokens still apply as they are, and each component's
markup is readable straight out of `bundle.js` to port into a Jinja macro. The class names
are the contract either way, so a ported `ScreenTable` and a mounted one look identical.

`previews/gallery.html` is the fastest way to see what you have. It needs no server and no
network: open the file.

## Regenerating

```bash
python3 tokens/build_tokens.py     # tokens.json → tokens.css
```

Stdlib only, no dependencies. Run it after any change to `tokens.json`; never edit
`tokens.css` by hand, since the next run overwrites it.

The rest of the files are copied from the artifact as they are. To refresh them, re-export
rather than patching: the artifact holds the same paths under `project/`, so
`project/components/bundle.js` here is `components/bundle.js`, `project/README.md` is
`docs/brand-book.md`, and `project/tokens.json` is `tokens/tokens.json`.

## For the agents working in this repo

Point them at `docs/brand-book.md` first — it is written as usage rules that name tokens,
which is what a coding agent needs, and it is short. Then `docs/values-and-provenance.md`
for how a number is allowed to be displayed (the three dates, the validity window, the two
provenance glyphs), and `docs/charts.md` before anything draws a chart. The per-component
files under `docs/components/` each say what the consumer supplies and what not to do.

Worth adding to `CLAUDE.md` or `AGENTS.md`: *"UI work follows
`design-system/docs/brand-book.md`. Use the tokens in `design-system/tokens/tokens.css`;
never hard-code a colour, size or radius."*

## Fonts

IBM Plex Sans and IBM Plex Mono, latin subset, weights 400/500/600, vendored rather than
loaded from Google Fonts: Fairband runs on localhost for one person, so this way it renders
identically with no network and no request leaves the machine on a page load.

They are under the SIL Open Font License 1.1, which is fine for a commercial product and
asks only that the licence travel with the files. The full text is in
[`fonts/LICENSE-IBMPlexSans.txt`](fonts/LICENSE-IBMPlexSans.txt) and
[`fonts/LICENSE-IBMPlexMono.txt`](fonts/LICENSE-IBMPlexMono.txt) — one per family, because
each carries its own copyright line. [`fonts/README.md`](fonts/README.md) has the
provenance and the three conditions worth knowing; the one that bites is that a build step
must not strip the licence files out when it copies the `.woff2`s.
