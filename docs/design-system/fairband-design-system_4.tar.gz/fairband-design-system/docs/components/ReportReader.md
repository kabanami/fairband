The agents' written report on a company: prose whose every number traces to a stored fact or an engine metric. Published or rejected whole. It changes no value.

## What the consumer provides

`mode`, either `valuation review` — every section except the business and the industry — or `full report`.

`state`, `published` or `rejected`.

On published: `revision`, and `cites` with the `snapshot`, `review` and `thesis` revisions, plus `reusesFullReportOf` when a review reuses an earlier full report's business and industry sections. Then `sections`, each `{ heading, parts }`, where a part is either a plain string or `{ cite, ref }`.

On rejected: `findings`, each `{ where, what, detail }` — the location, which of the six failures, and the specifics.

## The text in two steps: `reportText`

A page that lays a section's text out itself reads and draws it with `Fairband.reportText`, the reader's own two steps, so the page and `ReportReader` never differ on what a paragraph, a list or a table is.

`reportText.read(parts)` gives the section's blocks in the order the agent wrote them, each `{ kind, items }`. A `p` is a paragraph, its items its lines; a `ul` or an `ol` a list, its items its entries, and an `ol` the number it starts at, `start`; a `table` its rows of cells, under `head`, its header's rows. A line, an entry and a cell are each a list of pieces, a plain string or a `{ cite, ref }`.

`reportText.draw(block, footnotes, key)` gives one block's element under `key`: the element `ReportReader` draws for that block, each cite with its dotted underline, its ref in the title and its number from `footnotes` (ref → n), a table in its scroller. Hand it a map of footnotes, an empty one where the report has none.

`ReportReader` calls the two: it reads each section's parts and draws each block under its index.

## Rules

**A number in the prose is a `{ cite, ref }`, never a bare string.** The component cannot mark a number as cited without a reference, which is the display counterpart of the server's rule: a report is published only when every number resolves. If a figure has no reference, it renders as prose and looks like prose.

Cited numbers carry a dotted `accent` underline and name their reference in the title. The mark is quiet because, in a published report, *every* number has one — it is an affordance, not a warning.

**A rejection says the published report is unchanged**, in the card, in `caution`. The most likely misreading of a findings list is that the report is now broken; it is not, because a rejected submission never replaces the current revision.

The six failures are the server's words: unresolved reference, wrong unit, wrong period, wrong snapshot, a number with no reference, a derived figure the engine has not emitted. Don't paraphrase them — an agent fixing a submission will match on them.

Findings are located precisely — section, paragraph, citation index — because the agent has to find the one number that failed.

## Don't

Don't give this component an accept or a reject. The server validates; the Owner does not approve a report.

Don't show it as a source of value changes. A report cites a review; it does not create one.

Don't call it a memo.
