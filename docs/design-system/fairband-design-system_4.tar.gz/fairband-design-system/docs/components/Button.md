Four variants, two sizes. There are very few buttons in Fairband, which is why these four are enough.

## What the consumer provides

`variant`: `primary` for the one affirmative action on a surface, `secondary` for everything else, `quiet` for navigation that is not really an action, `danger` for reject and delete. Default `secondary`.

`size`: `sm` inside a card footer or a table row, `md` everywhere else.

`disabled`, `type`, `onClick`, `children`.

## Rules

One `primary` per surface, at most. On a `ProposalCard` that is Confirm; on an input form it is Save. If a surface seems to need two, one of them is really `secondary`.

Most surfaces have none. An override is applied by the time it renders and a report is validated by the server, so only a proposal carries buttons at all — a button on an agent record that is already settled would misrepresent how Fairband works.

Label a button with the thing it does and, where a count matters, the count: `Accept 3 inputs`, not `Accept`. `Save`, `Reject`, `Open detail`. Never `OK`, never `Submit`, never `Continue`.

`danger` is text-coloured `critical` with the ordinary border, and only fills on hover. A destructive action should be readable but not loud — the reader is scanning, not being warned.

A disabled button keeps its shape and takes `ink-faint` on `surface-sunken`. When a button is disabled because something is missing or has moved, say what, beside it — `ConfirmDialog` does this when its target has gone stale. A disabled control with no explanation is a dead end.

Focus is `focus-ring`, 2px, offset 2px, solid. It is never removed, and the hover transition is 120ms on colour only.

Buttons use the `control` type style. Nothing else in the system does.

## Don't

Don't put an icon in a button. Fairband has no icon set, and every glyph it does have means something specific.

Don't use a button for a link. `quiet` is for navigation inside the app; a real link is a link.

Don't add a loading state with a spinner. A recompute shows the old figures in `ink-faint` until the new ones land.
