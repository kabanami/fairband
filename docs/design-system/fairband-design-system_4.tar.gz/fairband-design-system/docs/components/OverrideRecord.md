A change to one tagged input, with its lifetime, reason and evidence. The server applies it at once if the rules allow, the engine recomputes, and the value bridge gains a line.

## When to use it

Wherever an override is shown after the fact: a company's history, an agent's activity, the audit. **The reader is looking at a record, not a request** — there is no accept, no reject and no confirm on this component, because the Owner does not gate input changes. Only a proposal waits for the Owner.

The Owner's own override form is a different surface with the same rules; this component shows its outcome.

## What the consumer provides

`tag`, `from`, `to` — the tagged input's path and its already-formatted old and new values, which may be percentages, multiples or money.

`lifetime`, either `lasting` or `period-tied`, with `period` naming the period or data point for the latter. Not optional: an override with no stated lifetime cannot be reasoned about, and a period-tied one expiring is what returns a value's basis to mechanical.

`reason` and `evidence`. Evidence is **required** on an override — a source document, a finding, a base rate, or a URL the server stored as text — each `{ kind, ref, note }`.

`principal` and `actor`, as everywhere.

`state`, one of `applied`, `refused-locked`, `refused-evidence`, `refused-unit`, `refused-not-input`, `conflict-stale`. On anything but `applied`, pass `message`: the rule that stopped it, in the terms the agent can act on.

On `applied`: `revisionFrom`, `revisionTo`, `effect` (per share), `reviewed`, `validUntil`.

## Rules

**The result is part of the record.** An override that does not say what it did to the value is a note, not an override. Show the effect per share, the new review revision and the validity.

**Refusals name the rule, not the failure.** "terminal.g is a locked input — the terminal growth ceiling" tells the agent what to do next; "invalid input" does not.

**A stale conflict is not a refusal.** It takes `record-stale`, not `record-refused`, because nothing is wrong with the write — it was aimed at a revision that has moved and succeeds once rebased. Colouring it like a refusal would send an agent to rewrite a correct override.

Evidence renders at full weight, never as an aside. It is required, so it is not a footnote.

## Don't

Don't put more than one input in one record. One override is one input; a set of changes is a set of records, each with its own outcome. The earlier `ReportCard` got this wrong, and it hid the fact that two changes in one submission can have two different fates.

Don't show an override as pending. By the time it is rendered the server has already applied or refused it.

Don't call it an adjustment or a tweak. It is an override.
