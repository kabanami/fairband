The value axis as three zones, with the band's own numbers, the levels that bound the zones, and the stance. This is the component the application is named after, and the one picture that answers the question the reader came with.

## What the consumer provides

`low` and `high`, the fair band. `price`, today's price. `fairValue`, the point estimate inside the band. `buyLevel` and `trimLevel`, the two thresholds. All per share, all numbers.

Optionally `caption` (name the phase model that produced the band), `width`, and `showScale: false` to drop the three threshold labels.

The component derives the stance from the price against the two levels. Never pass a stance in: a stance that can disagree with the levels beside it is worse than no stance.

## Rules

**The axis reads as three continuous zones, not as scattered markers.** `zone-buy` runs from the left edge to the buy level, `zone-hold` from buy to trim, and `zone-trim` from trim to the right edge. The band is drawn as `zone-fair`, a raised region *inside* hold — the band is not a fourth zone, it is where hold is most justified.

**Buy is a green-leaning teal and trim a terracotta.** Warm against cool, never a red against a green: under deuteranopia a literal green/red pair separates at ΔE 3.1 against a floor of 6, so the two zones that mean opposite things would become one colour for roughly one man in twelve. These two separate at 10.7. Red stays reserved for `critical` — expired and rejected — so a trim zone never collides with a stale figure beside it.

**The fair band carries no hue.** Fair means nothing to do, and the system already says that with absence of colour. A yellow band would say caution, which is what `caution` means. Hold and the band are told apart by lightness, which survives every colour-vision simulation.

**The band's own numbers go above the track**, in `figure-sm`, with a bracket marking their span. They are the engine's actual output — the buy and trim levels are derived from them — so they are never dropped to make room for their own consequences. The three threshold values sit below, each under its word.

**The price marker overhangs the track** top and bottom with a `radius-pill` cap above it, and carries a 2px `surface-raised` ring. The ring is load-bearing, not decoration: `ink` on the buy zone clears only 2.6:1, so without the ring the marker reads as a seam in the fill rather than a mark on the axis. It stays `ink` rather than the accent, because the accent is now the buy zone's own colour, and because the price line in `BandHistory` is `ink` too — the price is one colour everywhere.

Every zone carries its word inside it. Colour is reinforcement.

## Don't

Don't add a historical price line, a 52-week range or a second band **to this component**. It answers one question — where is the price today — in one glance. The history of the same two things is `BandHistory`, which sits directly below this on a company report.

Don't present the fair value as a target. It is a point on a distribution, which is why it is a thin tick inside the band rather than a heavy line.

Don't round the levels for tidiness. The engine computed them; display them as it produced them.

Don't show a band with no price, or a price with no band.
