The walk from the mechanical value to the reviewed one, one line per override. The only place a principal chip and a basis chip appear together, and the only place the difference between the two numbers is explained rather than asserted.

## What the consumer provides

`mechanical` and `reviewed`, both numbers, already computed by the engine.

`overrides`, in the order they apply, each `{ tag, from, to, delta, principal, actor, reason }`. `from` and `to` are already-formatted strings — they may be percentages, multiples or money, so the component does not format them. `delta` is the number's contribution to the reviewed value, in the same unit as `mechanical`.

`note`, one `caption` line beneath the table.

## Rules

**The column is arithmetic the reader can check.** The mechanical value is the opening term, each override contributes a signed delta, and the reviewed value sits under a `border-strong` rule as the sum. If the deltas do not add up to the difference, the engine is wrong and the bridge should show it rather than hide it — never fudge a residual into the last row.

Each row carries its own chip, and only its own: the value rows take a `BasisChip`, the override rows take a `PrincipalChip`. The glyph column carries `ƒ` and `◆` so the two families are legible down the left edge.

Every override shows its tag, its from→to and its reason in full. A missing reason is marked in `caution`, because an override without one should not have been saved.

Deltas take `stance-buy` when positive and `stance-trim` when negative — the same two hues as the zones, since a delta that raises the value is the same kind of thing as a price below the buy level.

## Don't

Don't collapse multiple overrides into "2 overrides, +$10.75". The reasons are the point of the component.

Don't order the rows by size of delta. They apply in sequence, and reordering them would misstate which input did what.

Don't show a bridge for a company with no overrides. The mechanical value is the value; a bridge with no middle rows is a heading with nothing under it.
