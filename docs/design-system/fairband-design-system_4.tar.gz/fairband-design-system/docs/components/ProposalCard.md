An agent's trade, policy change or thesis revision, waiting in the Inbox for the Owner. The only agent record with a confirm, and the only place in Fairband where an agent's work is gated by a person.

## What the consumer provides

`kind`, one of `trade`, `policy change` or `thesis revision`.

`principal` and `actor` — the agent and its role.

`reason` and `evidence`, as on an override.

`payload` — the exact change as the server will apply it, either an object or an array of `[field, value]` pairs. Pass what the server sent; do not summarise it.

`targetRevision`, the revision the proposal binds to, and `at`.

`state`: `pending`, `stale`, `confirmed` or `rejected`. On `stale`, `currentRevision`. On `confirmed`, `by` and `record` — the resulting record. On `rejected`, `by` and `rejectionReason`.

`onConfirm` opens the `ConfirmDialog`; `onReject` collects the Owner's reason.

## Rules

**The payload is shown, not described.** "Buy 120 BLDR" is a summary; the card shows the fields the server will act on, in a `surface-sunken` well, because the confirmation binds to exactly that.

**A stale card cannot be confirmed.** When the target moves, the card says so, names the current revision, and offers no confirm — a confirm that binds to nothing is worse than no button. The agent must propose again; there is no rebase in the UI.

**Confirming twice returns the same outcome.** The confirmed state says so, because an Owner who clicks again after a slow response needs to know they have not placed a second trade.

A rejection shows the Owner's reason at full weight, with the attribution beneath it. The reason is the useful part; who and when is metadata.

The payload stays visible on a stale card, muted, so the reader can see what they were about to approve.

## Don't

Don't use this for an override. An override is applied the moment the rules allow it — it never waits for anyone, and giving it a confirm would misrepresent how Fairband works.

Don't offer an edit. The Owner confirms or rejects what was proposed; changing it makes it a different proposal.

Don't call it a pending request.
