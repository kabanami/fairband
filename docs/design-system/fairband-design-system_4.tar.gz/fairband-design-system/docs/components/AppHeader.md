The one piece of chrome in Fairband: the mark and the name, where the reader is, and when the engine last ran.

## Why it is 44px

The header is the only thing on screen that tells the reader nothing about a company. At `row-height` 34px, every 34 pixels of chrome is one fewer row. 44px buys the mark at 24px with `space-2` above and below and nothing more, and that is the whole budget.

The cover is not a header. It is 288px, it is built to be the first thing anyone sees once, and at the top of the screen it costs five rows out of ten in a 520px window. Use the cover on the README, the docs landing page and the social card; use this on every page of the app.

## What the consumer provides

`views`, an array of `{ id, label, count? }`, plus `view` (the current `id`) and `onViewChange`. A `count` renders a small mono number beside the label — it exists for proposals waiting in the inbox, which is the only number in Fairband a reader needs before they have chosen a company.

`engineRanAt`, an ISO timestamp. It renders as `engine ran 29 Oct 2026, 03:12`, with the raw string in the `datetime` attribute.

`run`, while the engine is working: `{ total, done, failed?, stage?, onShowFailed? }`. It replaces `engineRanAt` for as long as it is set, and renders [`RunProgress`](RunProgress.md) in its compact form. The swap is the point — the stamp describes the last *finished* run, and leaving it up while a new one is underway reads as if the numbers below it are current.

`children`, if some surface needs a control up here. Nothing does yet, and the bar for adding one is that it applies to every view.

## Rules

The current view is marked twice: `ink` instead of `ink-muted`, and a 2px `accent` edge on the header's bottom rule. Never colour alone — the same pairing `ScreenTable` uses for a selected row.

`engineRanAt` is the one piece of state the header carries, and it is there because every number below it is only as good as that timestamp. If the engine has not run, pass nothing rather than a placeholder; an absent stamp is honest, `—` is noise.

No search field, no account menu, no settings gear. One user, no cloud, and the screen's own column chooser handles the only configuration there is.

Nothing in the header is a value, so no chip appears here. Provenance belongs beside the number it describes.

## Don't

Don't make it sticky with a shadow. If the screen scrolls under it, a `hairline` rule is the separation; `shadow-popover` is for things that float.

Don't grow it to fit a logo. The mark is sized to the header, not the other way round.

Don't put the company's name in it when the reader opens a company. The detail view has a `display` title of its own; repeating it in the chrome wastes the one line that says where in the app they are.
