One computed number, with the glyph that says the engine produced it and the word that says which inputs went in.

## What the consumer provides

`value`, a number. The component formats it as money — one currency, so the symbol goes in the text. Pass `format: 'plain'` and an already-formatted string for a percentage or a multiple.

`basis`, either `mechanical` or `reviewed`. Not optional: a number with no stated basis is the thing Fairband exists to abolish. Who wrote the overrides behind a reviewed value is a `PrincipalChip` on those overrides, not on this cell.

`freshness`, one of `current`, `aging` or `expired`, derived by the engine from the validity window. Defaults to `current`.

Optionally `asOf`, `observedAt`, `enteredAt` with `showDates` to append the three dates in `caption`; `showBasis: false` where a column header already names the basis; `emphasis: 'strong'` for the single headline number on a detail view; `align`.

## Rules

The `ƒ` leads, in `prov-derived`, separated from the figure by `space-1`, then the figure, then the basis word. The glyph is never dropped to recover width — drop the column instead, or use `ScreenTable`, which names its two value columns in their headers.

A `current` value is undecorated. An `aging` value takes `!` in `caution`; an `expired` value takes `×` in `critical` and a dotted `critical` underline. An expired value still shows its figure — Fairband never replaces a number it has with a dash. See [Values and provenance](../values-and-provenance.md).

Dates render as `3 Dec 2026` with the ISO string in `datetime`, so the reader reads words and a machine still reads ISO.

Figures are `mono` and right-aligned by default, so a column aligns on the decimal.

## Don't

Don't use it for an input. `TaggedInput` is the only component that renders a text field, and the visual difference between a computed number and an editable one is load-bearing.

Don't put a `PrincipalChip` beside it. The engine wrote this number, whoever wrote the inputs.

Don't colour the figure itself by direction or size. The glyph, the basis word and the freshness mark carry meaning; `ink` carries the number.
