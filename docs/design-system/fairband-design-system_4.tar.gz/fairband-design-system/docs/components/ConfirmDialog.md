The confirmation for a write that cannot be undone: a trade, a policy version, a thesis revision, a cancel. It shows the exact change the server will apply, and the confirmation binds to that.

## What the consumer provides

`title`, `payload` (the exact change, as sent by the server), `targetRevision`.

`state`: `open`, `stale`, `confirming` or `done`.

`onConfirm`, `onReject`, `onCancel`, and `onReload` for the stale state.

## Rules

**The dialog shows the payload, not a sentence about it.** The Owner is agreeing to specific fields; a prose summary would mean they confirmed something the dialog never showed them.

**Stale disables the confirm; it does not close the dialog.** If the target moves while the dialog is open, the reader needs to see that what they were about to approve is gone — closing it silently would leave them wondering where the card went. The payload stays visible, muted, and the confirm gives way to a reload.

The irreversibility is stated once, plainly, under the title. It is not repeated in the button label, which names the action: `Confirm`, not `Yes, I'm sure`.

`confirming` disables the confirm so a slow response cannot produce two writes. The Owner can still cancel.

## Don't

Don't use it for anything reversible. A dialog in front of an undoable action teaches the reader to click through dialogs.

Don't let it carry its own copy of the payload. It takes what the proposal holds, so the two can never disagree.

Don't put the reason field in here. The Owner's reject reason is collected by `ProposalCard`; this dialog confirms, rejects or cancels.
