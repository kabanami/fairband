A company's life-cycle phase, one of Damodaran's six, as a number and a name.

## The six phases

| Phase | Name | Token |
| --- | --- | --- |
| 1 | Start-up | `phase-1` |
| 2 | Young growth | `phase-2` |
| 3 | High growth | `phase-3` |
| 4 | Mature growth | `phase-4` |
| 5 | Mature stable | `phase-5` |
| 6 | Decline | `phase-6` |

These six are the taxonomy. Do not add a seventh, do not merge two, and do not invent a "turnaround" or "unknown" phase — a company whose phase the engine cannot determine has no badge at all, and the cell shows an em dash.

## What the consumer provides

`phase`, a number 1 through 6. Nothing else is required: the component supplies the name.

`label` overrides the name, and exists only for a shorter synonym in a narrow column. It is not a way to relabel the taxonomy.

`showLabel: false` renders the number alone, for the narrowest layouts. The number is always present; it is the primary signal, and the colour is reinforcement.

`size: 'sm'` tightens the padding for a table row.

## Rules

The number sits on the phase colour in `ink-inverse`; the name sits on `surface-raised` in `ink`. That split is deliberate — the coloured chip is small enough to stay quiet in a column of several thousand, and the name stays readable at any contrast.

The phase ramp runs cool and light at phase 1 to warm and dark at phase 6, so the six order themselves by lightness as well as hue. That ordering is the point: a reader scanning the column should see the shape of their universe without reading a single name.

Never reuse a `phase-*` token for a state, a status, a chart series or a category. They mean one thing.

A phase is a derived value — the engine assigns it. There is no editable phase badge. If the reader disagrees with a phase, they change the inputs that produced it.

## Don't

Don't put a tooltip on it that explains the taxonomy. The title attribute names the phase and its number out of six; a reader who wants the theory has Damodaran.

Don't animate a phase change. When a company moves phase, the row simply shows the new badge after the next recompute.
