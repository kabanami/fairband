An engine run over the universe, while it is happening: how many companies are valued, how many are waiting, how many failed.

## Three states and no fourth

A company in a run is valued, waiting, or failed. There is no "partial" and no "warning" — a value either came out of the engine or it did not, and the whole provenance model depends on that being true. If a company valued with a stale input, it is valued; the validity window on the value is what says so.

`pending` is never passed in. It is `total − done − failed`, so the three can never disagree with each other or with the total.

## What the consumer provides

`total`, the size of the universe this run covers. `done` and `failed`, the counts so far. Nothing else is required.

`stage`, a short lowercase verb phrase — `valuing` by default, or `fetching prices`, `reading filings`. It is rendered uppercase in the `label` style, like a column header.

`onShowFailed` turns the failed count into a button. Pass it wherever the app can actually show those companies — the natural thing is to filter the screen to them.

`compact` is the header form: a fixed 88px track and `2,841 of 4,112` instead of the separate done and pending counts. `AppHeader` does this for you when given `run`.

## Rules

**Determinate, always.** The engine knows the universe before it starts, so there is never a reason to show motion in place of a number. No spinner, no indeterminate sweep, no percentage where a count will do — a reader who sees `2,841 done` knows something a reader who sees `69%` does not.

**Every count that is zero is left out.** A run with no failures says nothing about failures; a finished run drops `pending` rather than printing `0 pending`. The absence is the message.

**A failure never disappears when the run ends.** `7 failed` stays on the finished run, and the app keeps showing it until the reader has seen which seven. A count that vanishes on completion is a count nobody acts on.

**The failed segment has a 3px floor.** Seven failures in four thousand is a third of a pixel, and a band nobody can see is a band that does not exist. The floor is smaller than the bar's own rendering precision, and the exact number is always written beside it — this is the one place the bar is not strictly to scale, and it is deliberate.

**Colour never carries a state alone.** `accent` is valued and `critical` is failed, and each is written out in words beside the bar. The bar is the shape of the run; the words are the run.

**While a run is in progress the screen keeps the last finished run's values.** Do not blank the table, do not grey the rows, do not show skeletons. The old numbers were true at the old timestamp, and the header has stopped claiming otherwise the moment `run` replaced the engine stamp — that is the whole point of the swap.

**No estimate unless the engine supplies one.** Fairband does not guess a finish time from a rate.

## Don't

Don't use this for anything that is not a run over the universe. A single company recomputing is not a progress bar; it is a value that is briefly absent.

Don't animate the bar beyond its width changing. The segment transition is 200ms linear and there is nothing else — no pulse, no shimmer, no stripes.

Don't put a percentage on it. Fairband counts companies.
