The only editable thing in Fairband: one tagged input, its value, its provenance and the reason it was changed.

## What the consumer provides

`label`, the human name of the input. `tag`, the stable MCP tag an agent addresses (`growth.rev_cagr_5y`, `wacc.erp`, `terminal.g`). Both are shown; the tag is shown because an agent will quote it in a report and the reader needs to match the two.

`value`, `unit`, `principal` and `actor`. `principal` is `owner`, `agent` or `system` and defaults to `owner`; `actor` is the model identifier when an agent set it. The glyph stays `◆` whoever wrote it, because the field is a write in every case — the principal beside it says who. `reason`, the author's text verbatim — while it is absent, the component shows the required-reason line in `caution`.

This component never shows a basis. `mechanical` and `reviewed` describe computed numbers; an input is neither.

`locked: true` renders read-only, for an input the current phase model does not use. A locked input keeps its border: it is still an input, just not one in play.

`onChange` is the only callback. There is no onSave — committing is the surrounding form's job, and it must refuse to commit without a reason.

## Rules

The tag is visible, always, in a `fb-tag` code chip in `figure-sm`. This is the contract between the person and their agents: whatever they call this field in conversation, the tag is what crosses the wire.

A reason is not optional. An input change with no reason does not get saved — not by the person, not by an agent — and the component states that rather than silently accepting the edit. See [Values and provenance](../values-and-provenance.md).

The reason renders in `body`, in full. Do not truncate it; it is the most valuable text in the application. Truncate the label first.

The field is right-aligned and monospaced (`figure`), on `surface-sunken` with `shadow-well`, so it reads as recessed without a heavier border than the controls around it.

Focus is `focus-ring`, 2px, offset 2px, and it is never removed — this is a form a person will drive from the keyboard for an hour at a time.

## Don't

Don't put a `TaggedInput` in a screen row. The screen is a read surface; changing inputs happens on a company's detail view, where the reason has room to be written.

Don't render a computed value in one. `ValueCell` exists so the two can never be confused, and the visual difference between them is load-bearing.

Don't validate the number's plausibility in the UI. The engine owns what is a valid input, and it will say so in terms the reader can act on.

Don't prefill a reason, suggest one, or carry one over from a previous edit.
