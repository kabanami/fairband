Value per share across a grid of two assumptions, coloured by how far each cell sits from today's price. The honest answer to "how much of this band is fact and how much is assumption".

## What the consumer provides

`rows` and `cols`, already-formatted header strings — terminal growth down, discount rate across, by convention. `cells[row][col]`, the value per share at that pair. `price`, today's price. `current`, the `{ row, col }` whose assumptions are in force. Optionally `rowLabel`, `colLabel`, `unit`, `title` and `subtitle`.

## Rules

**This is polarity, not magnitude.** The reader's question is not "how big is this number" but "is there margin of safety at this pair of assumptions", which is a question about a baseline — today's price. So the grid takes the diverging scale, not a sequential ramp: the cool `chart-pos` arm above the price, the warm `chart-neg` arm below, and `chart-mid` for cells within 2% of it, which must read as neither.

Three steps per arm, at 2%, 10% and 30% from the price. The arms are warm against cool so the two poles read as opposite, which two cool hues would not — and it keeps the grid off the red/green axis like everything else in Fairband.

**Every cell carries its value.** That is not decoration: it is the relief channel that lets the fills stay quiet, and it means no value in this component is reachable only by hovering. The grid is its own table twin, which is why it takes no `tableView`.

**Steps 1 and 2 carry `ink`; step 3 carries `ink-inverse`.** The strongest step inverts in both themes — light fill in dark mode, dark fill in light. Get it backwards and the cells that matter most become unreadable.

The assumption in force takes a 2px inset `border-strong` ring, not a different colour. Its colour still has to mean what every other cell's colour means.

## Don't

Don't use a rainbow, and don't put a hue at the midpoint. The midpoint must read as nothing.

Don't grow it past about 5 × 5. Past roughly seven classes in either direction, adjacent cells blur and the thing is a table pretending to be a picture — at which point make it a table.

Don't vary two assumptions the reader cannot change. Every axis here must correspond to a `TaggedInput` they or an agent can actually set, or the grid is a shrug.

Don't present a cell as a target. It is the value *if* those assumptions hold, and the assumptions are exactly what is uncertain.
