Which inputs went into a computed number: **mechanical** — the system's own inputs only — or **reviewed** — one or more overrides are inside. It sits on values, and never on a write.

## What the consumer provides

`basis`, either `mechanical` or `reviewed`.

`compact` drops the border and ground, for a chart header or a dense cell. `showGlyph: false` drops the `ƒ` for a context that already carries one — the glyph column in `ValueBridge`, or a table whose header has it.

## Rules

**No principal is printed on this chip.** `ƒ` already means the engine computed it, and the engine computes both the mechanical number and the reviewed one. Printing "System" beside the basis would restate the glyph; printing "Agent" would be false.

Reviewed takes the accent and a border; mechanical takes `ink-faint`. The asymmetry is deliberate — most numbers are mechanical, and the ones with a human or agent judgement inside are the ones worth checking first — but both always carry their word, so the distinction never rests on colour.

**The basis follows the inputs inside this number, not the company's history.** When a period-tied override expires, the value falls back to mechanical even though an agent once reviewed the company; the write stays in the history, but it is no longer inside this number. Equally, an Owner write that changes no valuation input — confirming a proposal, recording a trade, editing policy — moves no basis label at all.

In a table, don't put a chip in every cell. Name the two columns in their headers with the `ƒ` and let the cells stay plain figures; a three-thousand-row screen has no room for a chip per cell.

## Don't

Don't invent a third basis. "Partially reviewed" is not a thing: one override inside is reviewed.

Don't use `reviewed` to mean "an agent looked at this company". It means an override is inside this number, which is a different claim.

Don't show a reviewed value where no override exists — an em dash is the honest cell, and it is what the accuracy log compares against.
