The three dates a value carries, and the window the engine will keep trusting it inside.

## What the consumer provides

`asOf`, `observedAt`, `enteredAt`, `validFrom` and `validUntil`, all ISO date strings exactly as the engine produced them. The component renders them as `3 Dec 2026` and keeps the ISO string in each `datetime` attribute, so the reader reads words and anything parsing the markup still reads ISO.

`today` — the engine's own clock, not the browser's. A local app whose validity states depend on the machine's timezone will disagree with its own logs. It defaults to `enteredAt`, which is a safe fallback for a historical record, not a substitute for the real value.

`tag` — the MCP tag this window belongs to, shown above the dates in a `fb-tag` code chip.

## What each date means

**As of** is the date the fact describes: a fiscal period end, a filing date, a price timestamp. This is the date that belongs in a footnote.

**Observed** is when the value was read from its source. A wide gap between as-of and observed means the number is old news, not that it is wrong.

**Entered** is when it was written into Fairband. Audit questions are answered with this date, and for an accepted agent report it is the moment of acceptance, not the moment of research.

The three are never collapsed into one "updated" timestamp. Each answers a different question, and losing any of them loses an answer.

## Rules

The component draws the window as a `band-track`-high bar from `validFrom` to `validUntil`, with today's position marked by a 2px line with a `radius-pill` cap — the same shape as the price marker in `BandMeter`, because it means the same thing: a point on a scale.

Three states, each with a mark as well as a colour: current is undecorated, aging takes `!` in `caution` past two thirds of the window, expired takes `×` in `critical` past `validUntil`. The bar's fill shifts to `caution-quiet` or `critical-quiet` to match.

The threshold is two thirds of the window, not a fixed number of days. A quarterly figure and a discount-rate assumption age at very different speeds, and the window is the engine's own statement about which.

The dates render in `figure-sm`, which is monospaced, so a column of windows down a detail view aligns despite the varying day width.

## Don't

Don't compute `validUntil` in the UI from a rule of thumb. It comes from the engine, per value.

Don't hide an expired window. It is the most useful thing on the page at that moment.

Don't offer an extend-the-window control here. Extending a window is a change to an input, with a reason, through `TaggedInput`.
