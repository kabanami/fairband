Who made a write: Owner, Agent, or System. It sits on writes — an override, a proposal, a trade, a policy edit — and never on a computed number.

## What the consumer provides

`principal`, one of `owner`, `agent` or `system`.

`actor` — the agent's role, which in practice is the model identifier it connected under: `claude-opus-5`, `gpt-5`. Pass it exactly as it arrived over MCP, lower case, version suffix intact. Omit it for Owner and System.

`reason` — the author's text, verbatim, surfaced as the chip's title. Never rewrite or summarise it.

`at` — an ISO date or timestamp. The chip renders it as `3 Dec 2026` and keeps the ISO string in `datetime`.

`weight: 'strong'` gives the chip the `prov-input-quiet` ground, for a report header where the principal is the subject of the whole card. `compact` drops the border and ground for a table cell.

## Rules

**This chip never carries a basis word.** `mechanical` and `reviewed` belong to `BasisChip`, and a chip reading `◆ Agent claude-opus-5 · reviewed` is wrong however natural it looks: it implies the agent produced the number, and no agent ever produces a number. An agent changes an input; the engine recomputes. See [Values and provenance](../values-and-provenance.md).

The principal is the subject, in `ink`. The model identifier is supporting detail, in `ink-faint` and in `mono` — it is a string the reader will grep their MCP logs for, so it is never title-cased or uppercased.

Never write "AI", "assistant" or "bot" in `actor`. Fairband does not care what an agent is made of; it cares which model connected.

A write with no principal is not a write Fairband can show. There is no anonymous fallback worth relying on.

## Don't

Don't use it to show a data vendor, a source URL or a filing. The principal is who wrote the input into Fairband, which is a different question from where they read it. That belongs in the reason.

Don't put one on a value. Values get `BasisChip`, or nothing at all.

Don't show a pending report's chip against the value it proposes to change. Until the report is accepted, that value's basis is whatever it was before.
