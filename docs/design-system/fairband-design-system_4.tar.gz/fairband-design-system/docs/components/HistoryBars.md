One financial line by fiscal year, as columns. Revenue, FCFF, operating margin, reinvestment — one measure per chart, laid out as small multiples.

## What the consumer provides

`series`, oldest first, each `{ period, value }` plus an optional `freshness`. `title` names the measure and stands in for a legend. `unit` goes in `caption` beside the title. `format` overrides the compact tick formatter for percentages or multiples. Optionally `height` (default 180) and `tableView`.

## Rules

**One measure per chart.** Revenue and margin are two charts side by side, never one chart with two y-axes: the alignment between two scales is arbitrary and manufactures a correlation the data does not contain. This is the single most common way a financial chart lies.

**Columns start at zero.** A truncated baseline on a column chart misstates every ratio the reader takes from the bar lengths. If zero is far away, the chart is the wrong form — use a line.

**One series, one colour.** Every column is `chart-1`. Never tint a column darker because its value is bigger: length already shows magnitude, and spending the colour channel on it buys nothing.

The exception is a measure that crosses zero — FCFF, earnings, the spread. Then sign is polarity, and the component switches to the diverging pair: `chart-pos-3` above the baseline, `chart-neg-3` below, with the zero line in `border-strong`. It does this automatically when any value is negative.

Columns cap at `chart-bar-max` and never fill their slot; the leftover is air, and the gap between neighbours is `surface` showing through, not a stroke.

Only the last column is direct-labelled, on its cap. The y-axis carries the rest. A number over every column is chaos and goes unread.

A restated or lapsed year marks its **axis label** — `!` in `caution`, `×` in `critical` — not its column. Tinting the column would collide with the polarity scale and make a stale positive year look negative.

## Don't

Don't stack measures that are not parts of a whole. Revenue and cost are not a stack.

Don't sort the columns by value. The x-axis is time, and time has an order.

Don't draw a trend line through them. If the trend is the subject, the form is a line chart.
