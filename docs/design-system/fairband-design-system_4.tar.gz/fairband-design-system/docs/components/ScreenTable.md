The screen: one row per company, every number already computed, nothing editable. It is the first thing Fairband shows and the place its reader spends most of their time.

## When to use it

For any list of companies — the full universe above the size floor, a saved filter, the rows an agent touched this week. A different list of companies is the same table with different `rows`.

Not for a single company. A detail view composes `BandMeter`, `ValueBridge`, `ValidityWindow` and `TaggedInput` instead.

## What the consumer provides

`rows`, already filtered and sorted — `ScreenTable` does neither, and will not. Each row carries `ticker`, `name`, `phase`, the band (`fairLow`, `fairHigh`), `fairValue`, `buyLevel`, `trimLevel`, `price`, `mechanical`, `reviewed`, `overrides` (a count), and optionally `enteredAt`, `freshness` and `selected`.

`columns`, the visible column keys, with `onColumnsChange` to make the chooser live. Omit both and the default eight render with the chooser inert. `Fairband.DEFAULT_COLUMNS` is that default.

`sort` drives the header indicator only — sorting happens in the engine, the only thing that knows how to order a column of values with different validity states.

`dense` pulls rows to `row-height-dense`. `footnote` takes one `caption` line in the bar, for the row count and the size floor. `chooser: false` hides the column chooser.

`query` with `onQueryChange` puts the FIND field in the bar. `filters` with `onFiltersChange` puts *Filters ▾* beside *Columns ▾*. `total` is the size of the unfiltered universe; with it the bar says `41 of 4,112 · Clear` instead of a footnote.

**None of it filters anything.** The controls report what the reader asked for and the caller narrows `rows` — the same contract as `sort`. The component cannot filter correctly anyway: it never sees the rows that were excluded, which is exactly why `total` has to be passed in. `ScreenTable/preview.html` has the matching function, and it is the whole of the work: prefix-match the ticker, substring-match the name, then one `indexOf` per filter group.

## Finding and filtering

`Fairband.EMPTY_FILTERS` is the initial state. Each group is a whitelist: an empty array narrows nothing, a non-empty one keeps only what it names.

| Group | Values | From |
| --- | --- | --- |
| `stance` | `buy`, `hold`, `trim` | derived from price against the levels |
| `phase` | 1 – 6 | the engine's phase assignment |
| `cap` | `mega`, `large`, `mid`, `small` | `Fairband.CAPS`, with the range each covers |
| `sector` | the eleven GICS names | `Fairband.SECTORS` |
| `reviewedOnly`, `hideExpired` | booleans | the row's `reviewed` and `freshness` |

**There is no magnifying glass.** Fairband has no icon set and should not grow one, so the field is named by the word `FIND` in the column-header style. Nothing else in the bar carries a glyph either.

**Cap size is derived, like every other number.** It is price times shares at the last engine run, so a company moves between buckets on its own, and a filtered list is only as current as the engine stamp in the header. The buckets are the market's conventional four; the universe's size floor cuts below `small` and is not a bucket.

**Sector gets no colour.** Eleven hues would be a categorical palette, and Fairband does not have one — the only ordered colour ramp is the phase ramp, and reusing it for anything else is forbidden. Sector rows are plain text.

**Every active filter is stated in the bar as a word**, one chip per group: `Buy`, `Phase 4–6`, `Mid cap`, `Financials + Industrials`. A group with more than two selections becomes a count (`4 sectors`) so the bar stays one line however many filters accumulate. Clicking a chip clears that group; `Clear` beside the count clears everything, the query included.

## Rules

**Both values appear, each named by its column.** `ƒ Mechanical` and `ƒ Reviewed` carry the glyph in the header, and the cells stay plain figures — a three-thousand-row table has no room for a chip per cell. Mechanical sits in `ink-muted` as the reference; reviewed sits in `ink`.

**A company with no overrides shows an em dash under Reviewed**, not a repeat of the mechanical figure. A reviewed value that nobody reviewed would be a lie, and the dash is what the accuracy log compares against.

**Stance is derived**, from the price against the buy and trim levels, and always rendered as the word. Never pass a stance in.

**The chooser starts from the default eight and can always return to them.** Ticker and Price cannot be switched off. The default is what makes the screen one instrument rather than a spreadsheet; the reset is what makes departing from it safe.

Nothing in a row is a control. A reader who wants to change an input opens the company. The row's only interactions are hover, selection and opening.

Selection shows `surface-selected` plus the 2px `accent` inset edge, never the tint alone.

Dates render as `3 Dec 2026`, monospaced and right-aligned, with ISO in `datetime`. A `freshness` of `aging` or `expired` marks the date with `!` or `×`; a `current` row is left entirely undecorated.

## Don't

Don't colour whole rows by stance. The stance cell carries the word and its colour; a tinted row would drown the phase ramp and the basis columns both.

Don't add a sparkline, a logo or a change-on-day column **to the screen**. Every pixel one takes is a row the reader cannot see. History belongs on the company report, where `BandHistory` gives it room — see [Charts](../charts.md).

Don't paginate. Virtualise if the universe needs it; the reader scrolls one list.

Don't put a filter in the bar that is not also a column the reader can show. A filter on something invisible produces a list nobody can check.
