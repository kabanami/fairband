The price running through the fair-value band, quarter by quarter. The one chart the company report leads with, and the only picture that answers "has this ever been cheap, and is it cheaper now than it was".

## When to use it

Once per company report, above everything else. Never on the screen — a row has no space for it, and the screen's job is to narrow three thousand companies to a handful, not to tell their stories.

This replaces a bare price-trend line. A price chart on its own shows what the market did; the same line with the band behind it shows what the market did *relative to what the company is worth*, which is the only version a long-term value investor can act on. If you find yourself wanting a price chart without the band, what you actually want is this chart.

## What the consumer provides

`series`, oldest first, each point `{ period, price, fairLow, fairHigh }` plus an optional `freshness`. Periods are already-formatted labels; the component does not parse or bucket dates.

Optionally `title`, `subtitle` (use it to name the phase model that produced the band), `height` (default 220), and `tableView`.

The component derives below / in / above per period. Never pass a precomputed state.

## Rules

**The price line is one colour.** 2px `ink`, round join and cap, never recoloured by whether it sits above or below the band. Its position against the band already says that; tinting it would re-encode what the reader can see and collide with the diverging scale used elsewhere.

The band is a wash — `chart-band`, the hue at roughly 10% — with 1px `border-strong` edges, the same language `BandMeter` uses for the same thing. A band is a region the engine is willing to defend, not a target line.

The end marker carries a 2px `surface-raised` ring so it stays legible where it crosses the band edge, and the latest price is direct-labelled at the line end. That is the only value label on the plot; the axis and the crosshair carry the rest.

The chart measures its own container and draws at 1:1, so its 11px axis text is the same size as every other chart's. Do not wrap it in something that scales it.

Grid and axis rules are `chart-grid`, 1px, solid. A dashed rule here would read as a forecast.

A single series means no legend box. The title names what is plotted.

## Don't

Don't add a second band, a consensus target, a 52-week range or a moving average. One band, one price.

Don't extend the band into the future. The engine computes a band from inputs that have validity windows; drawing it past today claims a forecast Fairband does not make.

Don't animate the line in on load.
