# Charts

Charts belong on a company report, not on the screen. The screen answers "which of these three thousand companies is worth an hour", and it answers it in text; a chart there would cost a row. The report answers "is this one of them", and that question needs history.

## Pick the form before the colour

| What the reader must do | Form | Component |
| --- | --- | --- |
| See whether the price has ever been inside the band | price line over a shaded band | `BandHistory` |
| Compare one financial line year over year | column chart, one measure per chart | `HistoryBars` |
| See whether returns clear the cost of capital | two lines with the gap filled | `SpreadChart` |
| See how much of the band is assumption | diverging heatmap with values in the cells | `SensitivityGrid` |
| Read one current number | not a chart — a `ValueCell` with `emphasis="strong"` | — |

A single number is never a one-bar chart. Four headline numbers are never a grouped bar chart. If the answer is a number, print the number.

**One measure per chart.** Never two y-scales on one plot: the alignment between them is arbitrary and invents a correlation the data does not contain. Revenue and margin are two charts side by side, as small multiples, not one chart with two axes. `SpreadChart` carries two lines because ROIC and WACC are both percentages on one scale.

## Emphasis, not categorical colour

Fairband has one series hue. Every chart has a subject in `chart-1` and everything else in `chart-context`, the de-emphasis grey. That is the emphasis form, and it is the right one here because these charts always have a subject: the price, the measure, the return. There is no chart in Fairband where four series are equally the point, so there is no categorical palette to get wrong — and if one ever appears, the answer is small multiples, not more hues. One chart is the exception; see *Several series the reader picks*.

Because there is no categorical palette, the six categorical checks do not apply. `chart-context` is held to the 3:1 mark-contrast floor instead of the chroma floor — a de-emphasis grey is supposed to read as grey.

**Never colour a bar by its own value.** Bar length already shows magnitude; tinting it darker-where-bigger spends the identity channel re-encoding what the reader can already see. Every bar in a series is one colour.

**Never reuse a `phase-*` token in a chart.** Those six mean life-cycle phase and nothing else.

## Several series the reader picks

One chart in Fairband has no subject: the Financials tab's, where the reader picks up to four
lines and none is the point more than another. That chart, and only a chart like it, takes
`chart-1` to `chart-4`. Every other chart keeps one hue and `chart-context`.

- A line takes the lowest of the four that is free when it is picked and keeps it until it
  leaves the chart. Taking one line off never repaints the others. One line alone wears
  `chart-1`.
- Never a fifth colour: the chart holds four lines.
- Lines of one unit share a plot and a scale. Another unit takes a plot of its own under it, on
  the same periods. Never two scales on one plot.
- An amount is a column from zero; a rate is a line on an axis that fits its range.
- With one line, a figure below zero takes `chart-neg-3`, the polarity pair. With several, a
  column wears its line's colour above zero and below: colour is identity there.
- The legend is the row of labels above the plot, each a swatch, a name and the newest figure.
  Text never wears a series colour.
- This chart spans the page, so a column is at most 44px wide alone and 28px among several.
  `chart-bar-max` stays `HistoryBars`'s.
- The four were measured as a set: every pair is 10.6 or more apart under simulated protan and
  deutan sight and 21 or more under full sight (OKLab ΔE × 100), and each is 3:1 or more on
  `surface-raised`, in both themes. None is a `phase-*`, `caution` or `critical` value.

## Polarity uses the status pair

Above or below a baseline is polarity, so it takes the diverging scale: the cool `chart-pos-1/2/3` arm, the warm `chart-neg-1/2/3` arm, and `chart-mid` as a neutral grey midpoint that reads as nothing. The arms are warm against cool, which is what makes them read as opposite — two cool hues would not — and it keeps Fairband off the red/green axis everywhere.

`chart-pos-3` and `chart-neg-3` are the same values as `zone-buy` and `zone-trim` in `BandMeter`, and that is deliberate rather than coincidental: a negative FCFF year, a return below the cost of capital and a price above the trim level all mean the same kind of thing, so they are the same colour. Retune one and retune the other — parallel tokens that can drift apart would let a positive bar and a buy zone disagree. When a series means good or bad it wears this pair; when it is merely identity it wears `chart-1`.

Each arm is three steps, validated for monotone lightness, step gaps above 0.06 and a light end above 2:1 on the surface, in both themes. **Steps 1 and 2 carry `ink` as an in-cell label; step 3 inverts and carries `ink-inverse`.** Get that backwards and the strongest cells become unreadable.

## Marks

| Mark | Spec |
| --- | --- |
| Column | at most `chart-bar-max`, 4px rounded cap, square at the baseline, 2px `surface` gap between neighbours |
| Line | 2px, round join and cap |
| End marker | at least 8px across, with a 2px `surface` ring so it stays legible where it crosses a line |
| Area or band fill | the hue at roughly 10% — `chart-band`, never a saturated block |
| Grid and axes | `chart-grid`, 1px, **solid**. Never dashed: dashing reads as a projection or a threshold when it is only a grid |

Separate touching marks with a 2px gap in `surface`, never with a stroke around them. A stroke adds ink that is not data.

## Labels, legends and the table

**Text never wears the series colour.** Axis ticks, values and legend text take `ink-faint`, `ink-muted` or `ink`; identity comes from the coloured mark beside the text. The one exception is a label set inside a filled cell, which takes `ink` or `ink-inverse` by the fill's step.

**Label selectively.** The endpoint, the extreme, or the one year the story is about — never a number on every column. The axis, the legend and the tooltip carry the rest. A label that does not fit inside a mark moves outside it or drops to the tooltip; it is never clipped.

**A legend appears whenever a chart has two or more series, and never when it has one.** A one-swatch legend restates the title.

Axis ticks round to clean numbers and compact from a thousand up. They are monospaced, so they align.

**Axis ticks stay bare; direct labels and tooltips carry the currency symbol.** Elsewhere in Fairband the unit lives in the text — `$121.30` — but a `$` repeated down five gridline labels is chrome pretending to be data. The chart's title names the measure once.

**A table is optional.** No chart needs a table of its own: the rule that every chart has a table twin is withdrawn (the founder, 2026-11-16). A component may take `tableView`; no page of the app sets it. The hover box gives a mark's exact value, and keyboard focus shows what hover shows.

## Interaction

Line and area charts get a crosshair and a tooltip. Column, dot and cell charts get a per-mark tooltip. Hit targets are larger than the marks they belong to.

Filters sit in one row above everything they scope, never inside a chart. When the engine recomputes, hold the previous render at reduced opacity rather than flashing a skeleton — same rule as the screen.

Nothing animates on load. The 120ms colour transition on hover is the only motion a chart gets.

## Provenance in a chart

A chart is computed, so it carries one `BasisChip` in its header — mechanical or reviewed for the series as a whole — and no principal, because the engine drew every point. Where a year's inputs were restated or have lapsed, mark that year's axis label — `!` in `caution`, `×` in `critical` — rather than tinting the mark, which would collide with the polarity scale. The tooltip and the table carry the dates.
