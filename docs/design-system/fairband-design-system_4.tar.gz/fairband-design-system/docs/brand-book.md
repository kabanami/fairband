Fairband is a local instrument for one person. It runs on `localhost`, holds no account, sends nothing anywhere, and shows a screen of several thousand rows to someone who will open it most days for years. Design for that reader: no onboarding, no persuasion, no celebration. The numbers are the only loud thing on the page.

## Three rules above everything else

**The engine owns every value; everything else is a write.** One chip, one question: `ƒ` sits on a computed number and names its **basis** — mechanical or reviewed; `◆` sits on a write and names its **principal** — Owner, Agent or System. They never share a chip, because nobody but the engine writes a value, so the principal is the same for a mechanical number and a reviewed one. Never style a computed figure so it looks editable, and never style a write so it looks authoritative. `TaggedInput` is the only component with a text field in it; a screen cell is never a text field.

**A value without its dates is not a value.** Every value carries an as-of date, an observed date, an entered date and a validity window. If a surface has room for the value it has room for `ValidityWindow` or at least the `caption` line beneath it. See [Values and provenance](values-and-provenance.md) for what each date means and how to draw the window.

**Say it in words as well as colour.** Buy, hold, trim, aging, expired, mechanical, reviewed — each of these carries a word or a glyph next to the colour. A reader who sees no colour at all must lose nothing but speed.

**What the rules cover.** A *value* here is a figure Fairband itself states or records: the mechanical and the reviewed value, the levels, an input, an override, a record. The first two rules are about those and nothing else. They do not say that every number on a page needs a chip, a source or its dates. Reference data from a vendor — a company's statistics, prices, estimates, news — is shown plain: no chip, no cite, no vendor's name on a figure or a block, and one data date for the page or the block. A cite on every number is the rule of an agent's report alone ([ReportReader](components/ReportReader.md)), there so that research invents no number.

## Content fundamentals

Write in the second person for things the reader does ("Set a reason before saving") and in the third for things the engine does ("The engine recomputes on save"). Never write in the first person: Fairband has no voice of its own and never says "I".

Lower case for sentences, `label` uppercase for column headers and field labels, and ticker symbols exactly as the exchange writes them (`BRK.B`, not `BRK-B`). No title case in headings.

Name the mechanism, not the feeling. "Expired 2026-09-30" beats "needs attention". "`claude-opus-5` set this" beats "updated automatically". An error says what failed and what the reader can do: "Input `wacc` rejected — no reason given. Add a reason and submit again."

## The words

These are the product's terms. They are not interchangeable with their near-synonyms, and a surface that drifts off them stops matching the server's own vocabulary and the reader's.

| Use | Not | Means |
| --- | --- | --- |
| override | adjustment, tweak | a change to one tagged input, with its reason and evidence; lasting, or period-tied |
| review | analysis | the overrides on one snapshot and the reviewed result they produce |
| snapshot | baseline | a company's frozen inputs with the rules version, data date and price date |
| locked input | — | an input no override may change |
| finding | — | a dated, sourced fact an agent records |
| judgment | opinion | phase, moat, growth belief, ROIC or target margin, with bull view, bear view and decision |
| note | comment | a dated note on a company, with the same provenance as an override |
| news item | — | a dated item, marked with any kill criterion it triggers |
| report | memo | the agents' written report, in one of two modes |
| thesis | investment case | your dated view: the reasons for, the expected outcome, the kill criteria |
| proposal | pending request | an agent's trade, policy change or thesis change, awaiting your confirmation |
| work item | task, ticket | a request for an analysis, claimed and completed by an agent |
| find | search, query | matching a company by ticker or name; one field, labelled `FIND` |
| filter | screen (verb) | narrowing the universe by stance, phase, cap size or sector |
| the screen | watchlist, list | the one row-per-company view; "screen" is never the verb |

"Analysis" is reserved for the agents' work as a whole, so never use it for one review.

Name the model, never the category. An agent is identified by the model identifier it connected under — `claude-opus-5`, `gpt-5` — set in `mono`, lower case, exactly as it arrived. Never "AI", "assistant", "bot", or an invented nickname, and never uppercased: a model identifier is a string the reader will grep their own logs for, and changing its case breaks that.

No emoji anywhere, in the UI or in these guidelines. No exclamation marks. Quote the reader's own words back in a reason field without rewriting them.

**The unit goes in the text.** `$121.30`, not `121.30` with a `USD` caption beside it. Fairband covers US-listed companies only, so there is one currency and a separate unit never disambiguated anything; the symbol sits inside the monospaced run, so decimals still align. Percentages and multiples take their suffix the same way: `4.4%`, `1.18x`. Percentages carry one decimal at most.

**Dates read as `3 Dec 2026`.** The ISO string stays in `datetime` and the title, and the table view and exports emit ISO, so sorting and diffing are unaffected. Never a relative date. Dates are monospaced and right-align in a column.

## Visual foundations

**Colour.** Neutral by default. `surface` is the ground, `ink` is the text, and almost every row on the screen is those two plus `hairline`. One accent, `accent`, carries interaction. `caution` and `critical` mean exactly aging and expired. Six `phase-*` tokens carry the life-cycle ramp and nothing else; never reuse a phase colour for a state.

**The value axis.** `BandMeter` divides the axis into three continuous zones: `zone-buy` below the buy level, `zone-hold` between buy and trim with the band drawn inside it as `zone-fair`, and `zone-trim` at and above the trim level. Buy is a green-leaning teal and trim a terracotta — warm against cool, never a red against a green, which collapses to one colour for roughly one man in twelve. The band stays colourless because fair means nothing to do, and a yellow there would say caution, which is what `caution` already means.

`zone-buy` and `zone-trim` are the same values as `chart-pos-3` and `chart-neg-3`, so a buy zone and a positive bar can never disagree. The three stance words take `stance-buy`, `stance-hold` and `stance-trim`, which alias the zones they name.

Every text colour's usage note names the grounds it reads on, and each pair holds 4.5:1 in both themes. Where a colour becomes a fill, use its `on-*` partner for the text on it — do not reach for white, which fails on `caution` in dark.

**Type.** Set interface text in `sans` and every number in `mono`. That split is the system: if a thing is a quantity it is monospaced, so columns align on the decimal without tabular-figure tricks. `figure` for table cells, `figure-lg` for the one headline number on a detail view, `figure-sm` for band endpoints and from/to pairs, `ticker` for symbols. Use `control` inside buttons and inputs and nowhere else.

Fairband bundles IBM Plex Sans and IBM Plex Mono. The previews here load them from Google Fonts, but the app must not: vendor the `.woff2` files into the Python package and serve them from `localhost`, or the whole instrument stops rendering correctly on a plane. State the fallback stacks in `type.families` and keep them — a missing Plex should degrade to the system sans, not to a serif.

**Space and rhythm.** A 4px grid, with `space-1` through `space-3` doing most of the work. A screen row is `row-height`; `row-height-dense` is the same table with the chrome pulled in. Numeric columns are at least `figure-column` wide so a figure never wraps mid-page.

**Borders, not shadows.** `hairline` between rows and inside panels, `border` on anything a reader can act on, `border-strong` on hover and on the band's endpoints. `shadow-popover` is the only shadow and belongs to things that float. A panel never floats.

**States.** Hover is `surface-hover` and transient. Selection is `surface-selected` plus a 2px `accent` left edge — never the tint alone. Focus is `focus-ring`, 2px, offset 2px, solid, on every focusable control, and it is never removed. Disabled is `ink-faint` on `surface-sunken` with the border kept, so a disabled input still reads as an input.

**Radii.** `radius-sm` for chips and badges, `radius-md` for controls, `radius-lg` for panels. `radius-pill` is reserved for the provenance dot and the price marker's cap, so a pill in Fairband always means "a point on a scale".

**Motion.** Effectively none. Nothing animates on load, nothing eases in. The only transition allowed is a 120ms colour change on hover and focus. A recomputing screen shows the old figures at `ink-faint` until the new ones land; it does not spin.

**Charts.** Charts live on a company report, never on the screen. Fairband has one series hue and a de-emphasis grey — emphasis form, not categorical colour — plus a validated diverging scale for anything measured against a baseline. One measure per chart and never two y-axes. [Charts](charts.md) has the form heuristic, the palette slots, the mark specs and the rules that make a chart in Fairband honest; read it before drawing one.

**Density.** Prefer one more visible row to one more pixel of padding. When a layout has to give, cut the padding, not the row.

## Iconography

There is no icon set, and Fairband should not grow one. A handful of text glyphs carry all the meaning the UI needs, each paired with a word wherever there is room for one:

| Glyph | Means | Token |
| --- | --- | --- |
| `ƒ` | a computed number; the word beside it names the basis | `prov-derived` |
| `◆` | a write; the word beside it names the principal | `prov-input` |
| `!` `×` | value aging, value expired | `caution`, `critical` |

No glyph carries two meanings, and each answers one question: `ƒ` and `◆` answer whether a number was computed or chosen, and `!` and `×` answer whether it is still good. Where the price sits is said in words — Buy, Hold, Trim — and by the zone it lands in, not by a glyph.

A control is named by a word, never by a glyph the mono face would have to invent: the find field is labelled `FIND` in the column-header style, not with a magnifying glass, and the two menus are `Filters ▾` and `Columns ▾`.

Check any new mark against those first. Two earlier drafts failed here: one gave inputs a `▲`, which collided with "above band" two cells away in the same row, and one put a principal and a basis on the same chip, which implied an agent had produced a number.

All glyphs are drawn from IBM Plex Mono so they share an advance width and a column of them stays aligned. Do not reach for a dingbat or an emoji that the mono face does not carry; the fallback will render at a different width and the column will comb.

## The mark

Fairband has one mark: three unequal bands crossed by a price marker, which is the cover's picture cut to the fewest parts that still read at 24px. It is the app's own subject drawn at logo size — a value band, and a price standing in it — and it is the only decorative drawing in the system.

Inside the app it is `Fairband.Mark`, inline SVG that reads the tokens and follows the theme. Everywhere else it is a file from `assets/Logos/`, in the variant that matches the ground; those have their values baked in, and none of them use `currentColor`, because an SVG loaded through `<img>` never inherits it. [`assets/Logos/README.md`](../assets/Logos/README.md) is the usage sheet: clear space of a quarter the mark's width, a 16px floor, the one-ink fallback and its ink, and the rule that the bands fuse below about 20px and that this is intended.

The lockup is the mark at 24px, `space-2` of air, then *Fairband* in `sans` 600 at 16px in `ink`. The wordmark is live type — set it, never place an image of it — in `display` weight 600 with the final consonant cluster unbroken. The mark goes alone only where the name is already present or where there is no room for it: a favicon, a tab, a window icon.

The cover is a different object with a different job. It is 288px, it is built to be seen once, and it belongs on the repository README, the docs landing page, the social card and a splash on first launch. It is not chrome: above the screen it costs five rows out of ten in a 520px window, which is the opposite of the density rule two sections up. The application header is [`AppHeader`](components/AppHeader.md), it is 44px, and it carries the lockup, the current view and the engine's last run — nothing else.

## Using the components

Load `components/bundle.css` after `tokens.css`, then `components/bundle.js`, which assigns `window.Fairband`. React 18 must be on the page first. Every component is presentational: it takes data and renders it, holds no state and fetches nothing. Pass dates in as ISO strings exactly as the engine produced them; the components render them as `3 Dec 2026` and keep the ISO string in the `datetime` attribute, so the consumer never formats one itself.

`ScreenTable`, `ValueBridge` and `AppHeader` are the only components that compose others — `ScreenTable` uses `PhaseBadge` and `PrincipalChip`, `ValueBridge` uses both chips, `AppHeader` uses `Mark`. Build a new surface out of the small pieces rather than widening any of them with options.

Guidelines live beside each component in `components/<Name>/README.md`, and each one says what the consumer provides.
